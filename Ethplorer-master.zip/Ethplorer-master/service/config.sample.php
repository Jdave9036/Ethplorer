<?php
return array(
    "mongo" => array(
        "server" => "mongodb://127.0.0.1:27017",
        "dbName" => "everex-db",
    ),
    "ethereum" => "http://127.0.0.1:8545"
);
